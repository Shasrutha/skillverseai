# SkillVerse AI — Career Intelligence Demo

A responsive React + Vite starter application for a personalized career learning platform.

## Features included
- Dashboard with career readiness, skill map and roadmap progress
- Editable Career Digital Twin profile with local browser persistence
- Career simulator for five career paths
- Skill-gap visualization
- Interactive JavaScript assessment that updates the learner profile
- Adaptive milestone roadmap with completion toggles
- Six AI-agent information cards and a live activity log
- Reset demo control and responsive mobile layout

## Run on your laptop

1. Install **Node.js LTS** from https://nodejs.org/ if it is not already installed.
2. Extract this ZIP file.
3. Open the extracted `skillpath-ai` folder.
4. In that folder, open a terminal (or Command Prompt).
5. Run:

   ```bash
   npm install
   npm run dev
   ```

6. Open the local address printed in the terminal, usually `http://localhost:5173`.

## Deploy to Vercel

1. Create a new Vercel project and import this folder through a Git repository, or use Vercel's supported CLI workflow.
2. Framework preset: **Vite**
3. Build command: `npm run build`
4. Output directory: `dist`

## Important demo limitations
This is a front-end demo. The “AI agents” are simulated with local application logic and activity messages; no real LLM/API calls, authentication, cloud database, or server-side user accounts are connected. User changes are saved in the current browser using localStorage. Do not enter private or sensitive information.

This ZIP is a standalone starter and is not yet merged with the source code of your existing deployed Vercel website. Upload your existing project ZIP separately if you want the current site upgraded without losing its existing implementation.
