import React, { useEffect, useMemo, useState } from "react";

const careerData = {
  "Full Stack Developer": { skills: ["HTML & CSS", "JavaScript", "React", "Node.js", "SQL"], demand: "Very high", salary: "₹5–12 LPA", months: 6 },
  "AI Engineer": { skills: ["Python", "Machine Learning", "数学 & Statistics", "LLM APIs", "SQL"], demand: "Very high", salary: "₹7–18 LPA", months: 8 },
  "Data Scientist": { skills: ["Python", "Statistics", "SQL", "Machine Learning", "Data Visualization"], demand: "High", salary: "₹6–15 LPA", months: 7 },
  "Cybersecurity Analyst": { skills: ["Networking", "Linux", "Security Basics", "Python", "SIEM"], demand: "High", salary: "₹4–10 LPA", months: 7 },
  "Cloud Engineer": { skills: ["Linux", "Networking", "AWS/Azure", "Docker", "CI/CD"], demand: "High", salary: "₹5–13 LPA", months: 6 }
};

const initialProfile = {
  name: "Alex Morgan",
  education: "B.Tech — Computer Science",
  currentRole: "First-year engineering student",
  target: "Full Stack Developer",
  interests: "Building useful products, web development, problem solving",
  experience: "Beginner",
  skills: { "HTML & CSS": 65, "JavaScript": 35, "React": 15, "Python": 45, "SQL": 20 }
};

const initialRoadmap = [
  { title: "Web foundations", detail: "HTML, CSS, responsive layouts and accessibility", duration: "2 weeks", done: true },
  { title: "JavaScript essentials", detail: "Variables, functions, arrays, DOM and async basics", duration: "3 weeks", done: false },
  { title: "React development", detail: "Components, state, props, hooks and routing", duration: "4 weeks", done: false },
  { title: "Backend & databases", detail: "Node.js APIs, authentication and SQL", duration: "4 weeks", done: false },
  { title: "Portfolio project", detail: "Build and deploy a full-stack product", duration: "3 weeks", done: false }
];

function App() {
  const [tab, setTab] = useState("Overview");
  const [profile, setProfile] = useState(() => JSON.parse(localStorage.getItem("sv-profile") || "null") || initialProfile);
  const [roadmap, setRoadmap] = useState(() => JSON.parse(localStorage.getItem("sv-roadmap") || "null") || initialRoadmap);
  const [logs, setLogs] = useState(["Career Twin Agent created Alex’s learner profile.", "Skill Gap Agent mapped current skills to Full Stack Developer.", "Roadmap Agent generated a 16-week starter plan."]);
  const [assessment, setAssessment] = useState("");
  const [assessmentResult, setAssessmentResult] = useState("");
  const [showProfile, setShowProfile] = useState(false);
  const [simulated, setSimulated] = useState(false);

  useEffect(() => localStorage.setItem("sv-profile", JSON.stringify(profile)), [profile]);
  useEffect(() => localStorage.setItem("sv-roadmap", JSON.stringify(roadmap)), [roadmap]);

  const targetSkills = careerData[profile.target].skills;
  const gap = useMemo(() => targetSkills.map((skill, i) => {
    const level = profile.skills[skill] ?? [10, 15, 10, 5, 0][i % 5];
    return { skill, level, gap: 100 - level };
  }), [targetSkills, profile.skills]);
  const readiness = Math.round(gap.reduce((a, s) => a + s.level, 0) / Math.max(1, gap.length));
  const completed = roadmap.filter(x => x.done).length;

  function log(message) {
    setLogs(prev => [message, ...prev].slice(0, 8));
  }
  function updateProfile(key, value) {
    setProfile(prev => ({ ...prev, [key]: value }));
  }
  function changeTarget(value) {
    updateProfile("target", value);
    setSimulated(true);
    log(`Career Switch Agent simulated a transition to ${value}.`);
    log(`Skill Gap Agent recalculated ${careerData[value].skills.length} target skills.`);
  }
  function runAssessment() {
    if (!assessment) { setAssessmentResult("Choose an answer first."); return; }
    const correct = assessment === "function";
    setAssessmentResult(correct ? "Correct! A function is a reusable block of code." : "Not quite. The correct answer is “function” — it is a reusable block of code.");
    log("Assessment Agent evaluated the JavaScript fundamentals checkpoint.");
    if (correct) {
      setProfile(p => ({ ...p, skills: { ...p.skills, "JavaScript": Math.min(100, (p.skills["JavaScript"] || 0) + 10) } }));
      log("Career Twin Agent updated JavaScript proficiency by +10 points.");
    }
  }
  function resetDemo() {
    setProfile(initialProfile);
    setRoadmap(initialRoadmap);
    setAssessment("");
    setAssessmentResult("");
    setSimulated(false);
    setLogs(["Demo reset. Alex’s original learner profile has been restored."]);
    localStorage.removeItem("sv-profile");
    localStorage.removeItem("sv-roadmap");
    setTab("Overview");
  }

  const nav = ["Overview", "Career Twin", "Career Simulator", "Skill Assessment", "Learning Roadmap", "AI Agents"];
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">S</div><div><b>SkillVerse<span> AI</span></b><small>CAREER INTELLIGENCE</small></div></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>{nav.map((item, i) => <button key={item} className={tab === item ? "nav-item active" : "nav-item"} onClick={() => setTab(item)}><span>{["⌂","◈","⇄","✓","▤","✦"][i]}</span>{item}</button>)}</nav>
      <div className="sidebar-bottom"><div className="status-dot"></div><div><b>AI systems online</b><small>6 agents ready</small></div></div>
      <button className="reset-link" onClick={resetDemo}>↻ Reset demo</button>
    </aside>

    <main className="main">
      <header className="topbar"><div><div className="eyebrow">PERSONALIZED CAREER PLATFORM</div><h1>{tab}</h1></div><div className="top-actions"><span className="live-pill"><i></i> Demo environment</span><button className="avatar" onClick={() => setShowProfile(true)}>AM</button></div></header>
      <div className="content">
        {tab === "Overview" && <><section className="welcome"><div><div className="eyebrow light">YOUR CAREER, MADE CLEARER</div><h2>Welcome back, {profile.name.split(" ")[0]} <span>✦</span></h2><p>Your AI career team is tracking your progress toward becoming a {profile.target}.</p><button className="primary" onClick={() => setTab("Career Simulator")}>Explore career paths <span>→</span></button></div><div className="welcome-art"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="orbit-core">✦</div><div className="orbit-label label-a">SKILLS</div><div className="orbit-label label-b">GOALS</div><div className="orbit-label label-c">AI</div></div></section>
          <div className="stats-grid"><Stat label="Career readiness" value={`${readiness}%`} sub="Based on your target skills" icon="◈" /><Stat label="Skills mapped" value={targetSkills.length} sub="Across your target role" icon="⌘" /><Stat label="Roadmap progress" value={`${Math.round(completed / roadmap.length * 100)}%`} sub={`${completed} of ${roadmap.length} milestones`} icon="↗" /><Stat label="Target timeline" value={`${careerData[profile.target].months} mo`} sub="Estimated learning journey" icon="◷" /></div>
          <div className="two-col"><section className="panel"><PanelTitle title="Your skill gap" subtitle="Current proficiency vs. target role" action="View analysis" onClick={() => setTab("Career Twin")} />{gap.slice(0, 5).map(s => <SkillBar key={s.skill} {...s} />)}</section><section className="panel"><PanelTitle title="Learning roadmap" subtitle="Your next milestones" action="View roadmap" onClick={() => setTab("Learning Roadmap")} />{roadmap.slice(0, 4).map((r, i) => <div className="roadmap-mini" key={r.title}><div className={r.done ? "step-dot done" : "step-dot"}>{r.done ? "✓" : i + 1}</div><div className="roadmap-copy"><b>{r.title}</b><small>{r.duration} · {r.detail}</small></div><span className={r.done ? "done-tag" : "todo-tag"}>{r.done ? "Done" : "Next"}</span></div>)}</section></div>
        </>}
        {tab === "Career Twin" && <><div className="section-intro"><h2>Your Career Digital Twin</h2><p>A living profile that updates as you learn, practice and explore new goals.</p></div><div className="two-col twin-grid"><section className="panel"><PanelTitle title="Learner profile" subtitle="Edit your career identity" /><div className="field"><label>Full name</label><input value={profile.name} onChange={e => updateProfile("name", e.target.value)} /></div><div className="field"><label>Education</label><input value={profile.education} onChange={e => updateProfile("education", e.target.value)} /></div><div className="field"><label>Current role</label><input value={profile.currentRole} onChange={e => updateProfile("currentRole", e.target.value)} /></div><div className="field"><label>Experience level</label><select value={profile.experience} onChange={e => updateProfile("experience", e.target.value)}><option>Beginner</option><option>Intermediate</option><option>Advanced</option></select></div><div className="field"><label>Interests</label><textarea value={profile.interests} onChange={e => updateProfile("interests", e.target.value)} /></div><div className="save-note">✓ Changes are saved automatically on this device.</div></section><section className="panel"><PanelTitle title="Skill intelligence" subtitle="Your current skill levels" />{Object.entries(profile.skills).map(([skill, level]) => <div className="skill-edit" key={skill}><div><b>{skill}</b><strong>{level}%</strong></div><input type="range" min="0" max="100" value={level} onChange={e => updateProfile("skills", { ...profile.skills, [skill]: Number(e.target.value) })} /></div>)}<div className="insight-box"><span>✦ AI insight</span><p>Your strongest foundation is HTML & CSS. Focus on JavaScript and React next to move toward your selected career.</p></div></section></div></>}
        {tab === "Career Simulator" && <><div className="section-intro"><h2>Explore a new career direction</h2><p>Compare your current skills with the capabilities required for a target role.</p></div><section className="panel"><div className="field"><label>Select your target career</label><select value={profile.target} onChange={e => changeTarget(e.target.value)}>{Object.keys(careerData).map(c => <option key={c}>{c}</option>)}</select></div><div className="career-summary"><div><small>ROLE DEMAND</small><b>{careerData[profile.target].demand}</b></div><div><small>INDICATIVE SALARY RANGE</small><b>{careerData[profile.target].salary}</b></div><div><small>ESTIMATED LEARNING PLAN</small><b>{careerData[profile.target].months} months</b></div></div><div className="divider"></div><PanelTitle title="Your transition analysis" subtitle="Current proficiency against the selected role" />{gap.map(s => <SkillBar key={s.skill} {...s} />)}<div className="insight-box"><span>✦ Career Switch Agent</span><p>{readiness >= 60 ? "You have a useful foundation. Strengthen the remaining gaps with practical projects." : "This is an achievable learning journey. Build foundations first, then move into guided projects."} Your roadmap will adapt to this career target.</p></div>{simulated && <div className="success-note">✓ Career simulation updated. Your skill gap and dashboard now reflect {profile.target}.</div>}</section></>}
        {tab === "Skill Assessment" && <><div className="section-intro"><h2>Test what you know</h2><p>Short checkpoints help the AI team estimate your current proficiency.</p></div><div className="assessment-layout"><section className="panel quiz"><div className="quiz-top"><span className="tag">JAVASCRIPT · FUNDAMENTALS</span><span className="question-count">QUESTION 1 OF 1</span></div><h3>Which keyword is used to define a reusable block of code in JavaScript?</h3>{[["function","function"],["repeat","repeat"],["define","define"],["loop","loop"]].map(([v, label]) => <button key={v} onClick={() => setAssessment(v)} className={assessment === v ? "answer selected" : "answer"}><span className="radio">{assessment === v ? "●" : ""}</span>{label}</button>)}<button className="primary full" onClick={runAssessment}>Submit assessment <span>→</span></button>{assessmentResult && <div className="result-box">{assessmentResult}</div>}</section><section className="panel"><PanelTitle title="Assessment toolkit" subtitle="Available skill checkpoints" />{["HTML & CSS","JavaScript","React","Python","SQL"].map((s,i) => <div className="tool-row" key={s}><div className="tool-icon">{["⌘","JS","⚛","Py","DB"][i]}</div><div><b>{s}</b><small>{i === 1 ? "Ready to take" : "Practice checkpoint"}</small></div><span className="tool-arrow">→</span></div>)}</section></div></>}
        {tab === "Learning Roadmap" && <><div className="section-intro"><h2>Your adaptive learning roadmap</h2><p>Complete milestones to build momentum. Your progress is saved automatically.</p></div><section className="panel"><div className="roadmap-header"><div><span className="tag">PERSONALIZED PATH</span><h3>{profile.target} learning journey</h3><p>{completed} of {roadmap.length} milestones completed</p></div><div className="progress-ring"><b>{Math.round(completed / roadmap.length * 100)}%</b><small>DONE</small></div></div><div className="big-progress"><span style={{width: `${completed / roadmap.length * 100}%`}}></span></div><div className="roadmap-list">{roadmap.map((r,i) => <div className="roadmap-item" key={r.title}><div className={r.done ? "step-dot done" : "step-dot"}>{r.done ? "✓" : i + 1}</div><div className="roadmap-detail"><div className="roadmap-title"><b>{r.title}</b><span>{r.duration}</span></div><p>{r.detail}</p><button className={r.done ? "small-button completed" : "small-button"} onClick={() => {setRoadmap(prev => prev.map((x,j) => j === i ? {...x, done: !x.done} : x)); log(`Roadmap Agent ${r.done ? "reopened" : "completed"} milestone: ${r.title}.`);}}>{r.done ? "Mark as in progress" : "Mark complete"}</button></div></div>)}</div></section><div className="insight-box"><span>✦ Adaptive Roadmap Agent</span><p>As your skill levels change, revisit the Career Twin and Career Simulator. Use assessments to update your proficiency and choose the next milestone.</p></div></>}
        {tab === "AI Agents" && <><div className="section-intro"><h2>Your AI career team</h2><p>Specialized agents collaborate through a central orchestration layer.</p></div><div className="agent-grid">{[["◈","Career Twin Agent","Maintains your learner profile and evolving skill identity."],["⌕","Skill Gap Agent","Compares your current skills with target-role requirements."],["⇄","Career Switch Agent","Simulates transitions across five career pathways."],["✓","Assessment Agent","Evaluates quiz responses and updates proficiency."],["▤","Roadmap Agent","Builds milestones and adapts the learning journey."],["✧","Resource Agent","Suggests learning resources based on identified gaps."]].map(([icon,name,desc]) => <div className="panel agent-card" key={name}><div className="agent-icon">{icon}</div><div className="agent-state"><i></i> ACTIVE</div><h3>{name}</h3><p>{desc}</p></div>)}</div><section className="panel activity-panel"><PanelTitle title="Agent activity log" subtitle="Recent actions in this demo session" /><div className="activity-list">{logs.map((l,i) => <div className="activity" key={i}><span className="activity-pulse"></span><p>{l}</p><small>{i === 0 ? "JUST NOW" : `${i + 1}M AGO`}</small></div>)}</div></section></>}
      </div>
      <footer>SKILLVERSE AI <span>•</span> Personalized learning. Clearer careers. <span className="footer-right">DEMO VERSION 1.0</span></footer>
    </main>
    {showProfile && <div className="modal-backdrop" onClick={() => setShowProfile(false)}><div className="modal" onClick={e => e.stopPropagation()}><button className="close" onClick={() => setShowProfile(false)}>×</button><div className="avatar large">AM</div><h2>{profile.name}</h2><p>{profile.education}</p><div className="insight-box">Your profile is stored locally in this browser for the demo.</div><button className="primary full" onClick={() => {setShowProfile(false);setTab("Career Twin");}}>Edit career twin</button></div></div>}
  </div>;
}

function Stat({label,value,sub,icon}) { return <div className="stat-card"><div className="stat-icon">{icon}</div><small>{label}</small><strong>{value}</strong><p>{sub}</p></div>; }
function PanelTitle({title,subtitle,action,onClick}) { return <div className="panel-title"><div><h3>{title}</h3><p>{subtitle}</p></div>{action && <button onClick={onClick}>{action} →</button>}</div>; }
function SkillBar({skill,level,gap}) { return <div className="skill-row"><div className="skill-label"><b>{skill}</b><span>{level}% <small>proficiency</small></span></div><div className="bar-track"><div className="bar-fill" style={{width:`${level}%`}}></div></div><div className="gap-label">{gap}% gap</div></div>; }

export default App;
